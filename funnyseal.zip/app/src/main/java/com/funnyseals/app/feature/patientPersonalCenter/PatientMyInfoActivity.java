package com.funnyseals.app.feature.patientPersonalCenter;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.funnyseals.app.R;

public class PatientMyInfoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_my_info);
    }
}
