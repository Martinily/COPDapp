package com.funnyseals.server.comm;

/**
 * User Roles
 * 
 * @author Lynch 2014-09-15
 * 
 */
public interface Roles {

	/** USER_ROLE_APPADMIN value: appAdmin */
	public static String USER_ROLE_APPADMIN = "appAdmin";

}
